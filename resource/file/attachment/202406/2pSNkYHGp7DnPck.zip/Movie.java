public class Movie {
    private int id;
    private String title;
    private String director;
    private int votes;

    // 无参构造函数
    public Movie() {
    }

    // 全参构造函数
    public Movie(int id, String title, String director, int votes) {
        this.id = id;
        this.title = title;
        this.director = director;
        this.votes = votes;
    }

    // Getter 和 Setter 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    @Override
    public String toString() {
        return "Movie [id=" + id + ", title=" + title + ", director=" + director + ", votes=" + votes + "]";
    }
}
