import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;

@WebServlet("/votingsystem")
public class VotingSystemServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DataSource dataSource;

    @Override
    public void init() throws ServletException {
        super.init();
        // 配置数据源
        BasicDataSource ds = new BasicDataSource();
        ds.setUrl("jdbc:mysql://localhost:3306/movie");
        ds.setUsername("root");
        ds.setPassword("123456");
        ds.setMinIdle(5);
        ds.setMaxIdle(10);
        ds.setMaxOpenPreparedStatements(100);
        this.dataSource = ds;
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 创建DBUtils的QueryRunner
        QueryRunner queryRunner = new QueryRunner(dataSource);

        // 创建用于存放影片信息的列表
        List<Movie> movieList = new ArrayList<>();

        try {
            // 查询tb_vote表中的数据，并将每一条记录转换成Movie bean，存放在列表中
            movieList = queryRunner.query("SELECT * FROM tb_vote", new BeanListHandler<>(Movie.class));

            // 设置request属性，以便在JSP页面中使用
            request.setAttribute("movieList", movieList);

            // 转发到JSP页面进行显示
            request.getRequestDispatcher("/voting_system.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            // 处理异常情况
        }
    }
}
